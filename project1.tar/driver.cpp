#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "catalog.h"
#include "catalog.cpp"

using namespace std;

// fstream newfile;


int main(int argc, char* argv[1]) {
    string line;
    ifstream myfile ("filename.txt");

    //    if (argc < 3) {
  //  return 0;
    }
  //      ifstream m = (argv[1]);
    //    ifstream n = (argv[2]);
//    newfile.open(argv[1]);
  //  if (!newfile.fail()) {
      // (is this unccessary b/c user is using command line ? cin >> filename;
  //     cout << "File does not exist, Creating new file named:" << filename;
 //      newfile.open(filename);
      // newfile <<"\n";
       // newfile.close();
//    }}





